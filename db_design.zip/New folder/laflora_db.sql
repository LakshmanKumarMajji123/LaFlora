-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 29, 2025 at 01:37 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `laflora_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` int(15) NOT NULL,
  `title` varchar(255) NOT NULL,
  `path` blob NOT NULL,
  `d_ind` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `title`, `path`, `d_ind`) VALUES
(1, 'Clothing', '', 0),
(2, 'Salon Services', '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `colors`
--

CREATE TABLE `colors` (
  `id` int(10) NOT NULL,
  `name` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL,
  `d_ind` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `colors`
--

INSERT INTO `colors` (`id`, `name`, `image`, `d_ind`) VALUES
(1, 'Brown', '', 0),
(2, 'Red', '', 0),
(3, 'Green', '', 0),
(4, 'Blue', '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(10) NOT NULL,
  `subcategory_id` int(10) NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` varchar(300) NOT NULL,
  `MRP` varchar(20) NOT NULL,
  `discount` decimal(5,2) NOT NULL,
  `rating` varchar(10) NOT NULL,
  `reviews` varchar(10) NOT NULL,
  `image` varchar(255) NOT NULL,
  `stocks_id` int(10) NOT NULL,
  `d_ind` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `subcategory_id`, `name`, `description`, `MRP`, `discount`, `rating`, `reviews`, `image`, `stocks_id`, `d_ind`) VALUES
(1, 5, 'KHUSHAL K', 'Flora Printed Empire Kurta with Trouser & With Dupatta', '1264', 5.00, '4.3', '2.6k', '', 0, 0),
(2, 1, 'GOSRIKI', 'Women Ethnic Motifs Printed Regular Kurta with Palazzos', '1264', 5.00, '4.5', '2.6k', '', 0, 0),
(3, 4, 'KHUSHAL K', 'Flora Printed Empire Kurta with Trouser & With Dupatta', '1619', 5.00, '5', '2.6k', '', 0, 0),
(4, 4, 'KHUSHAL K', 'Flora Printed Empire Kurta with Trouser & With Dupatta', '1619', 5.00, '5', '2.6k', '', 0, 0),
(5, 5, 'KHUSHAL K', 'Flora Printed Empire Kurta with Trouser & With Dupatta', '1264', 5.00, '4.3', '2.6k', '', 0, 0),
(6, 3, 'GOSRIKI', 'Flora Printed Empire Georgatte Anarkali Kurtha', '1119', 5.00, '5', '2.6k', '', 0, 0),
(7, 6, 'GOSRIKI', 'Flora Printed Empire Kurta with Trouser & With Dupatta', '1619', 5.00, '5', '2.6k', '', 0, 0),
(8, 2, 'Sitaramam Designer', 'Flora Printed Empire Kurta with Trouser & With Dupatta', '1619', 5.00, '5', '2.6k', '', 0, 0),
(9, 4, 'KHUSHAL K', 'Flora Printed Empire Kurta with Trouser & With Dupatta', '1619', 5.00, '5', '2.6k', '', 0, 0),
(10, 1, 'GOSRIKI', 'Women Ethnic Motifs Printed Regular Kurta with Palazzos', '1264', 5.00, '4.5', '2.6k', '', 0, 0),
(11, 3, 'GOSRIKI', 'Flora Printed Empire Georgatte Anarkali Kurtha', '1119', 5.00, '5', '2.6k', '', 0, 0),
(12, 4, '', '', '', 0.00, '', '', '', 0, 0),
(13, 5, '', '', '', 0.00, '', '', '', 0, 0),
(14, 1, '', '', '', 0.00, '', '', '', 0, 0),
(15, 6, '', '', '', 0.00, '', '', '', 0, 0),
(16, 3, '', '', '', 0.00, '', '', '', 0, 0),
(17, 5, '', '', '', 0.00, '', '', '', 0, 0),
(18, 6, '', '', '', 0.00, '', '', '', 0, 0),
(19, 5, '', '', '', 0.00, '', '', '', 0, 0),
(20, 3, '', '', '', 0.00, '', '', '', 0, 0),
(21, 3, '', '', '', 0.00, '', '', '', 0, 0),
(22, 6, '', '', '', 0.00, '', '', '', 0, 0),
(23, 5, '', '', '', 0.00, '', '', '', 0, 0),
(24, 1, '', '', '', 0.00, '', '', '', 0, 0),
(25, 3, '', '', '', 0.00, '', '', '', 0, 0),
(26, 5, '', '', '', 0.00, '', '', '', 0, 0),
(27, 3, '', '', '', 0.00, '', '', '', 0, 0),
(28, 3, '', '', '', 0.00, '', '', '', 0, 0),
(29, 1, '', '', '', 0.00, '', '', '', 0, 0),
(30, 2, '', '', '', 0.00, '', '', '', 0, 0),
(31, 4, '', '', '', 0.00, '', '', '', 0, 0),
(32, 5, '', '', '', 0.00, '', '', '', 0, 0),
(33, 5, '', '', '', 0.00, '', '', '', 0, 0),
(34, 3, '', '', '', 0.00, '', '', '', 0, 0),
(35, 6, '', '', '', 0.00, '', '', '', 0, 0),
(36, 5, '', '', '', 0.00, '', '', '', 0, 0),
(37, 1, '', '', '', 0.00, '', '', '', 0, 0),
(38, 6, '', '', '', 0.00, '', '', '', 0, 0),
(39, 5, '', '', '', 0.00, '', '', '', 0, 0),
(40, 3, '', '', '', 0.00, '', '', '', 0, 0),
(41, 3, '', '', '', 0.00, '', '', '', 0, 0),
(42, 5, '', '', '', 0.00, '', '', '', 0, 0),
(43, 2, '', '', '', 0.00, '', '', '', 0, 0),
(44, 1, '', '', '', 0.00, '', '', '', 0, 0),
(45, 2, '', '', '', 0.00, '', '', '', 0, 0),
(46, 5, '', '', '', 0.00, '', '', '', 0, 0),
(47, 5, '', '', '', 0.00, '', '', '', 0, 0),
(48, 3, '', '', '', 0.00, '', '', '', 0, 0),
(49, 6, '', '', '', 0.00, '', '', '', 0, 0),
(50, 5, '', '', '', 0.00, '', '', '', 0, 0),
(51, 6, '', '', '', 0.00, '', '', '', 0, 0),
(52, 5, '', '', '', 0.00, '', '', '', 0, 0),
(53, 3, '', '', '', 0.00, '', '', '', 0, 0),
(54, 3, '', '', '', 0.00, '', '', '', 0, 0),
(55, 5, '', '', '', 0.00, '', '', '', 0, 0),
(56, 6, '', '', '', 0.00, '', '', '', 0, 0),
(57, 1, '', '', '', 0.00, '', '', '', 0, 0),
(58, 6, '', '', '', 0.00, '', '', '', 0, 0),
(59, 1, '', '', '', 0.00, '', '', '', 0, 0),
(60, 3, '', '', '', 0.00, '', '', '', 0, 0),
(61, 3, '', '', '', 0.00, '', '', '', 0, 0),
(62, 3, '', '', '', 0.00, '', '', '', 0, 0),
(63, 3, '', '', '', 0.00, '', '', '', 0, 0),
(64, 1, '', '', '', 0.00, '', '', '', 0, 0),
(65, 1, '', '', '', 0.00, '', '', '', 0, 0),
(66, 3, '', '', '', 0.00, '', '', '', 0, 0),
(67, 2, '', '', '', 0.00, '', '', '', 0, 0),
(68, 6, '', '', '', 0.00, '', '', '', 0, 0),
(69, 5, '', '', '', 0.00, '', '', '', 0, 0),
(70, 6, '', '', '', 0.00, '', '', '', 0, 0),
(71, 5, '', '', '', 0.00, '', '', '', 0, 0),
(72, 2, '', '', '', 0.00, '', '', '', 0, 0),
(73, 1, '', '', '', 0.00, '', '', '', 0, 0),
(74, 5, '', '', '', 0.00, '', '', '', 0, 0),
(75, 5, '', '', '', 0.00, '', '', '', 0, 0),
(76, 6, '', '', '', 0.00, '', '', '', 0, 0),
(77, 4, '', '', '', 0.00, '', '', '', 0, 0),
(78, 5, '', '', '', 0.00, '', '', '', 0, 0),
(79, 5, '', '', '', 0.00, '', '', '', 0, 0),
(80, 5, '', '', '', 0.00, '', '', '', 0, 0),
(81, 1, '', '', '', 0.00, '', '', '', 0, 0),
(82, 1, '', '', '', 0.00, '', '', '', 0, 0),
(83, 6, '', '', '', 0.00, '', '', '', 0, 0),
(84, 3, '', '', '', 0.00, '', '', '', 0, 0),
(85, 5, '', '', '', 0.00, '', '', '', 0, 0),
(86, 1, '', '', '', 0.00, '', '', '', 0, 0),
(87, 5, '', '', '', 0.00, '', '', '', 0, 0),
(88, 5, '', '', '', 0.00, '', '', '', 0, 0),
(89, 1, '', '', '', 0.00, '', '', '', 0, 0),
(90, 1, '', '', '', 0.00, '', '', '', 0, 0),
(91, 5, '', '', '', 0.00, '', '', '', 0, 0),
(92, 3, '', '', '', 0.00, '', '', '', 0, 0),
(93, 4, '', '', '', 0.00, '', '', '', 0, 0),
(94, 3, '', '', '', 0.00, '', '', '', 0, 0),
(95, 5, '', '', '', 0.00, '', '', '', 0, 0),
(96, 3, '', '', '', 0.00, '', '', '', 0, 0),
(97, 2, '', '', '', 0.00, '', '', '', 0, 0),
(98, 5, '', '', '', 0.00, '', '', '', 0, 0),
(99, 1, '', '', '', 0.00, '', '', '', 0, 0),
(100, 6, '', '', '', 0.00, '', '', '', 0, 0),
(101, 5, '', '', '', 0.00, '', '', '', 0, 0),
(102, 6, '', '', '', 0.00, '', '', '', 0, 0),
(103, 5, '', '', '', 0.00, '', '', '', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `product_quality`
--

CREATE TABLE `product_quality` (
  `id` int(10) NOT NULL,
  `quality_type` varchar(255) NOT NULL,
  `d_ind` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `product_quality`
--

INSERT INTO `product_quality` (`id`, `quality_type`, `d_ind`) VALUES
(1, 'Higher Denser', 0),
(2, 'Premium', 0),
(3, 'Comfort', 0);

-- --------------------------------------------------------

--
-- Table structure for table `sizes`
--

CREATE TABLE `sizes` (
  `id` int(10) NOT NULL,
  `sizes` varchar(20) NOT NULL,
  `quantity_left` varchar(20) NOT NULL,
  `d_ind` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `sizes`
--

INSERT INTO `sizes` (`id`, `sizes`, `quantity_left`, `d_ind`) VALUES
(1, 'S', '10', 0),
(2, 'M', '20', 0),
(3, 'L', '25', 0),
(4, 'XL', '10', 0);

-- --------------------------------------------------------

--
-- Table structure for table `specifications`
--

CREATE TABLE `specifications` (
  `id` int(10) NOT NULL,
  `quality` varchar(255) NOT NULL,
  `Sleeve_Length` varchar(255) NOT NULL,
  `Collar` varchar(255) NOT NULL,
  `Fit` varchar(255) NOT NULL,
  `Brand_Fit_Name` varchar(255) NOT NULL,
  `Print_or_Pattern_Type` varchar(255) NOT NULL,
  `Occasion` varchar(255) NOT NULL,
  `d_ind` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `stocks`
--

CREATE TABLE `stocks` (
  `id` int(10) NOT NULL,
  `colors_id` int(10) NOT NULL,
  `sizes_id` int(10) DEFAULT NULL,
  `specifications_id` int(10) DEFAULT NULL,
  `d_ind` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `stocks`
--

INSERT INTO `stocks` (`id`, `colors_id`, `sizes_id`, `specifications_id`, `d_ind`) VALUES
(1, 4, NULL, NULL, 0),
(2, 1, NULL, NULL, 0),
(3, 2, NULL, NULL, 0),
(4, 3, NULL, NULL, 0);

-- --------------------------------------------------------

--
-- Table structure for table `sub_categories`
--

CREATE TABLE `sub_categories` (
  `id` int(15) NOT NULL,
  `category_id` int(15) NOT NULL,
  `title` varchar(255) NOT NULL,
  `d_ind` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `sub_categories`
--

INSERT INTO `sub_categories` (`id`, `category_id`, `title`, `d_ind`) VALUES
(1, 1, 'Kurthas & Kurthis', 0),
(2, 1, 'Dresses', 0),
(3, 1, 'Bottom Wear', 0),
(4, 1, 'Blouses', 0),
(5, 2, 'Hair Cut', 0),
(6, 2, 'Wax', 0);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(10) NOT NULL,
  `registration_id` int(10) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `category_id` int(10) DEFAULT NULL,
  `d_ind` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `registration_id`, `name`, `category_id`, `d_ind`) VALUES
(1, 1, 'Majji Lakshman Kumar ', 2, 0),
(2, 2, 'Rajesh ', 1, 0),
(3, 3, 'Teja', 1, 0),
(4, 4, 'Prasad ', 2, 0),
(5, 5, 'Ram kumar', 2, 0);

-- --------------------------------------------------------

--
-- Table structure for table `user_registration`
--

CREATE TABLE `user_registration` (
  `id` int(15) NOT NULL,
  `name` varchar(255) NOT NULL,
  `phonenumber` varchar(25) NOT NULL,
  `email` varchar(50) NOT NULL,
  `otp` varchar(4) NOT NULL,
  `otp_expires` datetime NOT NULL,
  `d_ind` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user_registration`
--

INSERT INTO `user_registration` (`id`, `name`, `phonenumber`, `email`, `otp`, `otp_expires`, `d_ind`) VALUES
(1, 'Majji Lakshman Kumar ', '9182016992', 'lakshmankumarmajji@gmail.com', '6625', '2025-07-29 17:04:00', 0),
(2, 'Rajesh ', '9347966681', 'rajesh@gmail.com', '9643', '2025-07-28 10:48:03', 0),
(3, 'Teja', '8099011117', 'tej@gmail.com', '9327', '2025-07-28 16:41:26', 0),
(4, 'Prasad ', '9010933109', 'prasad@gmail.com', '5107', '2025-07-28 17:47:08', 0),
(5, 'Ram kumar', '7569833314', 'ram@gmail.com', '7682', '2025-07-29 16:12:26', 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `colors`
--
ALTER TABLE `colors`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`),
  ADD KEY `subcategory_products` (`subcategory_id`);

--
-- Indexes for table `product_quality`
--
ALTER TABLE `product_quality`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sizes`
--
ALTER TABLE `sizes`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `specifications`
--
ALTER TABLE `specifications`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `stocks`
--
ALTER TABLE `stocks`
  ADD PRIMARY KEY (`id`),
  ADD KEY `colors_stocks` (`colors_id`),
  ADD KEY `sizes_stocks` (`sizes_id`),
  ADD KEY `specifications_stocks` (`specifications_id`);

--
-- Indexes for table `sub_categories`
--
ALTER TABLE `sub_categories`
  ADD PRIMARY KEY (`id`),
  ADD KEY `categories_subcategories` (`category_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD KEY `userRegistration_users` (`registration_id`),
  ADD KEY `category_users` (`category_id`);

--
-- Indexes for table `user_registration`
--
ALTER TABLE `user_registration`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `colors`
--
ALTER TABLE `colors`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=104;

--
-- AUTO_INCREMENT for table `product_quality`
--
ALTER TABLE `product_quality`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `sizes`
--
ALTER TABLE `sizes`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `specifications`
--
ALTER TABLE `specifications`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `stocks`
--
ALTER TABLE `stocks`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `sub_categories`
--
ALTER TABLE `sub_categories`
  MODIFY `id` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `user_registration`
--
ALTER TABLE `user_registration`
  MODIFY `id` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `products`
--
ALTER TABLE `products`
  ADD CONSTRAINT `subcategory_products` FOREIGN KEY (`subcategory_id`) REFERENCES `sub_categories` (`id`);

--
-- Constraints for table `stocks`
--
ALTER TABLE `stocks`
  ADD CONSTRAINT `colors_stocks` FOREIGN KEY (`colors_id`) REFERENCES `colors` (`id`),
  ADD CONSTRAINT `sizes_stocks` FOREIGN KEY (`sizes_id`) REFERENCES `sizes` (`id`),
  ADD CONSTRAINT `specifications_stocks` FOREIGN KEY (`specifications_id`) REFERENCES `specifications` (`id`);

--
-- Constraints for table `sub_categories`
--
ALTER TABLE `sub_categories`
  ADD CONSTRAINT `categories_subcategories` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`);

--
-- Constraints for table `users`
--
ALTER TABLE `users`
  ADD CONSTRAINT `category_users` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`),
  ADD CONSTRAINT `userRegistration_users` FOREIGN KEY (`registration_id`) REFERENCES `user_registration` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
